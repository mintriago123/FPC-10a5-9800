/* libfpcbep.so is dynamically linked by linux libfprint module during runtime. */

================
libfpcbep installation
================
1. sudo chmod 755 install.sh
2. ./install.sh

